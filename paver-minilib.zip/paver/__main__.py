import paver.tasks
paver.tasks.main()
